"""Test suite for AnthosKS."""
