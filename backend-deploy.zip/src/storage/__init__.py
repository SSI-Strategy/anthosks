"""Storage abstraction module."""
