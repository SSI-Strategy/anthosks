"""Analytics module for MOV report analysis."""
