"""Extraction module for MOV reports."""
