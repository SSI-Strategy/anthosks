"""Database abstraction module."""
